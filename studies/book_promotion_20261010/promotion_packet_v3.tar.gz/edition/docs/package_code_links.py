"""Keep repository-code links usable in a standalone Quarto HTML export."""
from __future__ import annotations

import html
import os
from pathlib import Path
import re
import shutil
from urllib.parse import quote, unquote, urlsplit, urlunsplit


def package(output: Path, code: Path) -> int:
    output, code = output.resolve(), code.resolve()
    count = 0
    for page in output.rglob('*.html'):
        # A copied HTML code resource is source material, not a rendered page.
        if page.is_relative_to(output/'code'):
            continue

        def replace(match):
            nonlocal count
            uri = urlsplit(html.unescape(match[2]))
            relative = Path(unquote(uri.path[len('../code/'):]))
            source = (code/relative).resolve()
            if not source.is_relative_to(code) or not source.is_file():
                raise ValueError(f'Missing or unsafe code resource: {match[2]}')
            target = output/'code'/source.relative_to(code)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            path = quote(Path(os.path.relpath(target, page.parent)).as_posix())
            link = html.escape(urlunsplit(('', '', path, uri.query, uri.fragment)), quote=True)
            count += 1
            return 'href='+match[1]+link+match[1]

        original = page.read_text(encoding='utf-8')
        rewritten = re.sub(r'''\bhref=(["'])(\.\./code/[^"']+)\1''', replace, original)
        if rewritten != original:
            page.write_text(rewritten, encoding='utf-8')
    return count


if __name__ == '__main__':
    project = Path(os.environ['QUARTO_PROJECT_DIR']).resolve()
    output = Path(os.environ['QUARTO_PROJECT_OUTPUT_DIR'])
    if not output.is_absolute():
        output = project/output
    if output.resolve() == project:
        raise ValueError('HTML packaging requires a separate output directory')
    print(f'Packaged {package(output, project.parent/"code")} code-resource links.')
