# PDE: shared task instructions

PDE and PDE-2 use this same `/home/amir/Codes/PDE` checkout and Git index.
Do not clone, move or copy it, create parallel worktrees, or reset others' work.

For lead-author research, default to a new study. Reuse an existing study
only when the user explicitly directs the current work to that study, or
when the current task created it and the request clearly continues the
same investigation.

A materially different research question or direction requires a new study,
even within the task that created the earlier study, unless the user
explicitly directs otherwise. Related topics, shared data or conversation
continuity alone do not justify reuse. Routine implementation, corrections
and validation of the same investigation count as continuation; when
continuation is unclear, default to a new study.

Read-only tasks, scoped subagents and isolated reviewers retain their
existing scope rules.

The established scientific book is the Quarto edition under `docs/`. Its entry
point is `docs/index.qmd`, and its global notation contract is
`docs/notation.qmd`. Treat this edition as the maintained authority. The
pre-Quarto book under `old_docs/` is a frozen diagnostic archive, not an
alternative source: do not read or search it by default. Only when a specific
current passage is ambiguous, apparently corrupted, or has a broken reference
may a task report that defect and inspect the minimum corresponding passage in
`old_docs/`. Do not silently substitute archived wording for current material;
repair or escalate the current book instead.

## Mathematical communication

Minimize the reader's translation work. Use established domain notation and
the user's agreed conventions; define symbols before use or alongside their
first defining formula. Give central objects explicit definitions in already
defined quantities. Introduce new symbols only when they materially improve
understanding. Make each mathematical passage self-contained for its requested
scope, including the setup, assumptions and relations needed to follow it.

Before producing mathematical explanations, derivations, proofs, research notes,
reviews or scientific interpretations of experiments, read and apply
`explain-with-canonical-notation` at
`/home/amir/.codex/skills/explain-with-canonical-notation/SKILL.md`.
Apply it in conversation and written artifacts, including research that was not
requested as a lesson. For neural-network material, also read its linked
neural-network reference. Reuse already-read instructions while current; purely
operational work with no mathematical content does not require the full skill.

These presentation requirements apply alongside the task's research, proof,
review or teaching workflow. They do not expand source access or impose a
lesson pace. Honor the user's requested scope, including complete rewrites.
Preserve the source mathematics and give exact correspondences when translating
notation; the maintained book retains its global notation contract.

## Reading and research scope

Before acting, select the appropriate reading scope:

- **Research:** read Part 1 of `RESEARCH_WORKFLOW.md` and your study's README.
  Read complete relevant sources and corrections within the study boundary below.
  Read `docs/index.qmd` and `docs/notation.qmd` for scientific work, and
  `code/README.md` when using or changing maintained APIs.
- **Promotion:** also read Part 2 of `RESEARCH_WORKFLOW.md` completely.
- **Repository maintenance:** read the workflow and use only the assigned shared
  paths; keep working artifacts in the relevant maintenance study.
- **Scoped research subagent:** follow the supervisor's explicit input scope;
  it may be prompt-only or selected book/code material. This replaces ordinary
  author startup reading, including the study README. Required skills and process
  instructions still apply; report missing scientific inputs without fetching them.
- **Independent isolated review:** read only the neutral assignment, complete
  frozen inputs and required skills. Do not perform author startup or read
  study history, prior verdicts or another reviewer's findings. Report missing
  inputs; write only the assigned report and study-owned scratch.
- **Read-only questions:** read only the assigned sources needed for the answer;
  this is not permission to browse other studies.

Each study's repository research inputs are its own artifacts and generated data,
and the established `docs/` and `code/` with their designated reproduction inputs.
`old_docs/` is excluded except for the narrow diagnostic fallback above.
Do not read or search other studies, or obtain their research through links,
chats, summaries, Git history, or other agents. Shared instructions, required
skills, and metadata-only coordination remain available. See Part 1 for scoped
delegation; independent attempts start fresh without inherited discussion.

Studies organize research directions; tasks organize conversations and work.
One task may coordinate several studies through separate research contexts;
several tasks may share a study. Unpromoted findings do not cross study boundaries.
Keep each study's source and evidence in its flat `studies/<name>/` folder and
its generated products in `data/generated/<name>/`. Its existing README is the
only required administrative record; additional ledgers and the helper are optional.

Keep internally checked results distinct from established material. Promotion
requires relevance screening, fresh complete independent reviews, self-contained
canonical theory/reusable code, and user approval of the concrete reviewed addition.
The workflow specifies the checks; an internal PASS or helper result cannot replace them.

Preserve concurrent changes and coordinate one Git writer using the common lock
in the workflow. Existing tasks must reread changed instructions before substantive
work. These files guide all tasks in this checkout; they are not OS confinement.
